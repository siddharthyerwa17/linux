$(function(){
    $("#wizard").steps({
        headerTag: "h2",
        bodyTag: "section",
        transitionEffect: "fade",
        enableAllSteps: true,
        transitionEffectSpeed: 500,
        labels: {
            finish: "Submit",
            next: "Forward",
            previous: "Backward"
        },
        onStepChanging: function (event, currentIndex, newIndex) {
            // Check form validity before allowing the user to proceed
            if (newIndex > currentIndex) {
                if (!isFormValid(currentIndex)) {
                    return false; // Prevent moving to the next step if the form is not valid
                }
            }
            return true; // Allow moving to the next step
        }
    });

    // Function to check form validity for a specific step
    function isFormValid(stepIndex) {
        var valid = true;
        $("#wizard").find("section").eq(stepIndex).find("input[required]").each(function() {
            if (!$(this).val()) {
                valid = false;
                return false; // Exit the loop early if an empty required field is found
            }
        });
        return valid;
    }

    $('.wizard > .steps li a').click(function(){
        $(this).parent().addClass('checked');
        $(this).parent().prevAll().addClass('checked');
        $(this).parent().nextAll().removeClass('checked');
    });

    // Custom jQuery Step Button
    $('.forward').click(function(){
        // Move to the next step only if the form is valid
        if (isFormValid($("#wizard").steps("getCurrentIndex"))) {
            $("#wizard").steps('next');
        }
    });

    $('.backward').click(function(){
        $("#wizard").steps('previous');
    });

    // Select Dropdown
    $('html').click(function() {
        $('.select .dropdown').hide();
    });

    $('.select').click(function(event){
        event.stopPropagation();
    });

    $('.select .select-control').click(function(){
        $(this).parent().next().toggle();
    });

    $('.select .dropdown li').click(function(){
        $(this).parent().toggle();
        var text = $(this).attr('rel');
        $(this).parent().prev().find('div').text(text);
    });
});
